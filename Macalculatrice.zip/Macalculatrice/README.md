# Just a simple Calculator

> Repository associated to the french MOOC :
> Développez des applications Android connectées

Here is the appearence of the activity (thx to @mlr46):

![Appearence of the Calculator](./Appearence.png)
